 <footer class="footer">
    © {{date('Y-m-d')}} Developed by
    <a href="">JuicyCodes.com</a>
</footer>

