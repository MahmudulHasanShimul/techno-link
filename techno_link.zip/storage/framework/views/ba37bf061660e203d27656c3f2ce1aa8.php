<?php $__env->startSection('title'); ?>
Packages | Techno Link
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Page Title Area -->
<div class="page-title-area">
    <div class="container">
        <div class="page-title-content">

        </div>
    </div>
</div>
<!-- End Page Title Area -->
<!-- Start Pricing Area -->
<section class="pricing-area ptb-100 pt-0 mt-5">
    <div class="container">
        <div class="section-title">
            <span>
                <span class="icon">
                    <i class="flaticon-resume"></i>
                </span>

                <span>Bahama Pricing</span>
            </span>
            <h2>Discover our best plans</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices.</p>
        </div>

        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-pricing-table">
                    <div class="pricing-header">
                        <div class="icon">
                            <i class="flaticon-online-shop"></i>
                        </div>

                        <span>TV + Internet</span>
                        <h3>Player Bundle</h3>
                    </div>

                    <ul class="pricing-features-list">
                        <li><i class="flaticon-check-mark"></i> 150+ channels</li>
                        <li><i class="flaticon-check-mark"></i> Catch Up & On Demand</li>
                        <li><i class="flaticon-check-mark"></i> Cell Phone Connection</li>

                    </ul>

                    <div class="price">
                        <span>From</span>
                        <span>$</span>
                        67.99
                        <span>/mo</span>
                    </div>

                    <div class="image-box">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/shape-image/2.png" alt="image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/shape-image/2.png" alt="image">
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="single-pricing-table">
                    <div class="pricing-header">
                        <div class="icon">
                            <i class="flaticon-online-shop"></i>
                        </div>

                        <span>TV + Internet</span>
                        <h3>Player Bundle</h3>
                    </div>

                    <ul class="pricing-features-list">
                        <li><i class="flaticon-check-mark"></i> 150+ channels</li>
                        <li><i class="flaticon-check-mark"></i> Catch Up & On Demand</li>
                        <li><i class="flaticon-check-mark"></i> Cell Phone Connection</li>
                    </ul>

                    <div class="price">
                        <span>From</span>
                        <span>$</span>
                        67.99
                        <span>/mo</span>
                    </div>

                    <div class="image-box">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/shape-image/2.png" alt="image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/shape-image/2.png" alt="image">
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3">
                <div class="single-pricing-table">
                    <div class="pricing-header">
                        <div class="icon">
                            <i class="flaticon-online-shop"></i>
                        </div>

                        <span>TV + Internet</span>
                        <h3>Broadband & WIFI</h3>
                    </div>

                    <ul class="pricing-features-list">
                        <li><i class="flaticon-check-mark"></i> 150+ channels</li>
                        <li><i class="flaticon-check-mark"></i> Catch Up & On Demand</li>
                        <li><i class="flaticon-check-mark"></i> Cell Phone Connection</li>
                    </ul>

                    <div class="price">
                        <span>From</span>
                        <span>$</span>
                        99.99
                        <span>/mo</span>
                    </div>

                    <div class="image-box">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/shape-image/2.png" alt="image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/shape-image/2.png" alt="image">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Pricing Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\a-xampp\htdocs\techno-link\resources\views/website/package/package.blade.php ENDPATH**/ ?>