<link href="<?php echo e(asset('/')); ?>admin/assets/fontawesome/css/all.min.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/dropify/dist/css/dropify.min.css"  rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/morrisjs/morris.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/summernote/dist/summernote-bs4.css" rel="stylesheet">

<!--Toaster Popup message CSS -->
<link href="<?php echo e(asset('/')); ?>admin/assets/node_modules/toast-master/css/jquery.toast.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="<?php echo e(asset('/')); ?>admin/dist/css/style.min.css" rel="stylesheet">
<!-- Dashboard 1 Page CSS -->
<link href="<?php echo e(asset('/')); ?>admin/dist/css/pages/dashboard1.css" rel="stylesheet">
<?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/admin/includes/style.blade.php ENDPATH**/ ?>