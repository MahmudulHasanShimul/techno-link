 <footer class="footer">
    © <?php echo e(date('Y-m-d')); ?> Developed by
    <a href="">JuicyCodes.com</a>
</footer>

<?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>