


<?php $__env->startSection('body'); ?>
<!-- Start Customer list Area -->

<div class="row mt-5  col-md-111 mx-auto mb-5">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><b><?php echo e($reSellers->company_name); ?></b> (<?php echo e($reSellers->owner_name); ?>) Clients List</h4>
            <hr>

            <?php if(Session::get('noti')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('noti')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>


            <?php if(Session::get('msg')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('msg')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-striped border table-hover">
                    <thead>
                        <tr>
                            <th>SL NO</th>
                            <th>Client Name</th>
                            <th>User Id</th>
                            <th>Phone Number</th>
                            <th>Package</th>
                            <th>Package Rate</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0;
                        ?>
                       <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->user_id); ?></td>
                                <td><?php echo e($client->phone_number); ?></td>
                                <td><?php echo e($client->package); ?> MB</td>
                                <td><?php echo e($client->package_rate); ?></td>

                                <?php
                                    $total = $total + $client->package_rate;
                                ?>

                                <td>
                                    <?php if($client->status == 'Active'): ?>
                                        <p class="card-text" style="color: green; font-weight:bold">Active</span></p>
                                    <?php else: ?>
                                        <p class="card-text" style="color: red; font-weight:bold">Inactive</p> 
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <a href="<?php echo e(route('resellerWiseClient.details',['id'=>$client->id])); ?>" class="btn btn-primary" title="Details">
                                        Details
                                    </a>
                                </td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                            <th><b>TOTAL</b></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th><b><?php echo e($total); ?></b></th>
                            <?php
                                Session::put('total_amount', $total);
                            ?>
                            <th></th>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Start Customer list Area -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/admin/reSeller/client-list.blade.php ENDPATH**/ ?>