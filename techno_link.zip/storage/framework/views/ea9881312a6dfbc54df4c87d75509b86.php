


<?php $__env->startSection('body'); ?>
<div class="row mt-3">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Resellers List</h4>
            <hr>

            <?php if(Session::get('noti')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('noti')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>


            <?php if(Session::get('msg')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('msg')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-striped border table-hover">
                    <thead>
                        <tr>
                            <th>SL NO</th>
                            <th>Owner Name</th>
                            <th>Mobile Number</th>
                            <th>Active Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $reSellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reSeller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($reSeller->owner_name); ?></td>
                                <td><?php echo e($reSeller->mobile); ?></td>
                                <td>
                                    <?php if($reSeller->status == 1): ?>
                                        <p class="card-text" style="color: green; font-weight:bold">Active</span></p>
                                    <?php else: ?>
                                        <p class="card-text" style="color: red; font-weight:bold">Inactive</p> 
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('reselller.details',['id'=>$reSeller->id])); ?>" class="btn btn-info"> <i class="fa-solid fa-circle-info"></i> </a>
                                    <a href="<?php echo e(route('reselller.edit',['id'=>$reSeller->id])); ?>" class="btn btn-success"> <i class="fa fa-edit"></i> </a>
                                    <a href="<?php echo e(route('reselller.delete',['id'=>$reSeller->id])); ?>" class="btn btn-danger"> <i class="fa fa-trash"> </i> </a>
                                </td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/admin/reSeller/manage.blade.php ENDPATH**/ ?>