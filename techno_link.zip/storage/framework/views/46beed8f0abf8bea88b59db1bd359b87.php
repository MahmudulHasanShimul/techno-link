 <div class="right-sidebar">
     <div class="slimscrollright">
         <div class="rpanel-title"> Service Panel <span><i class="ti-close right-side-toggle"></i></span> </div>
         <div class="r-panel-body">
             <ul id="themecolors" class="m-t-20">
                 <li><b>With Light sidebar</b></li>
                 <li><a href="javascript:void(0)" data-skin="skin-default" class="default-theme">1</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-green" class="green-theme">2</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-red" class="red-theme">3</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-blue" class="blue-theme working">4</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-purple" class="purple-theme">5</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-megna" class="megna-theme">6</a></li>
                 <li class="d-block m-t-30"><b>With Dark sidebar</b></li>
                 <li><a href="javascript:void(0)" data-skin="skin-default-dark" class="default-dark-theme ">7</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-green-dark" class="green-dark-theme">8</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-red-dark" class="red-dark-theme">9</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-blue-dark" class="blue-dark-theme">10</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-purple-dark" class="purple-dark-theme">11</a></li>
                 <li><a href="javascript:void(0)" data-skin="skin-megna-dark" class="megna-dark-theme ">12</a></li>
             </ul>
         </div>
     </div>
 </div>

<?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/admin/includes/rightbar.blade.php ENDPATH**/ ?>