
<?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/auth/register.blade.php ENDPATH**/ ?>