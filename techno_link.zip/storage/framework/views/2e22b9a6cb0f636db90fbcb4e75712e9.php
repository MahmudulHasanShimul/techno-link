<?php $__env->startSection('title'); ?>
Contact | Techno Link
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

        <!-- Start Page Title Area -->
        <div class="page-title-area">
            <div class="container">
                <div class="page-title-content">

                </div>
            </div>
        </div>
        <!-- End Page Title Area -->


        <!-- Start Contact Info Box Area -->
        <section class="contact-info-box-area ptb-100 pb-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-contact-info">
                            <div class="icon">
                                <i class="flaticon-place"></i>
                            </div>
                            <h3>Address</h3>
                            <p>176, Street Name, New York, NY 10014176, <br> USA</p>

                            <div class="image-box">
                                <img src="assets/img/shape-image/1.png" alt="image">
                                <img src="assets/img/shape-image/1.png" alt="image">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-contact-info">
                            <div class="icon">
                                <i class="flaticon-address-book"></i>
                            </div>
                            <h3>Email</h3>
                            <p><a href="#"><span class="__cf_email__" data-cfemail="e58c8b838aa59c8a9097968c91808b848880cb868a88">[email&#160;protected]</span></a></p>
                            <p><a href="#"><span class="__cf_email__" data-cfemail="b8cfcfcf96c1d7cdcad6d9d5ddf8dfd5d9d1d496dbd7d5">[email&#160;protected]</span></a></p>

                            <div class="image-box">
                                <img src="assets/img/shape-image/1.png" alt="image">
                                <img src="assets/img/shape-image/1.png" alt="image">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3">
                        <div class="single-contact-info">
                            <div class="icon">
                                <i class="flaticon-signal"></i>
                            </div>
                            <h3>Phone</h3>
                            <p><a href="#">+2(976) 432-998</a></p>
                            <p><a href="#">+2(976) 432-998</a></p>

                            <div class="image-box">
                                <img src="assets/img/shape-image/1.png" alt="image">
                                <img src="assets/img/shape-image/1.png" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Info Box Area -->

        <!-- Start Contact Area -->
        <section class="contact-area ptb-100">
            <div class="container">
                <div class="section-title">
                    <span>Send Message</span>
                    <h2>Drop us message for any query</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra.</p>
                </div>

                <form id="contactForm">
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Your Name" name="name" id="name" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Your Email Address" name="email" id="email" required data-error="Please enter your email">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" name="phone_number" placeholder="Phone Number" id="phone_number" required data-error="Please enter your number">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" name="msg_subject" placeholder="Subject" id="msg_subject" required data-error="Please enter your subject">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-12 col-md-12">
                            <div class="form-group">
                                <textarea name="message" class="form-control" id="message" cols="30" rows="10" placeholder="Type Your Message Here" required data-error="Write your message"></textarea>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-12 col-md-12">
                            <button type="submit" class="btn btn-primary">Send Message</button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <!-- Start Contact Area -->

        <!-- Start Map Area -->
        <div id="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d913.2953021491431!2d90.44634146962694!3d23.705222126619336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b98b57057851%3A0x774b297ccadc0d95!2sTechno%20Link!5e0!3m2!1sen!2sbd!4v1684929972286!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <!-- End Map Area -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\a-xampp\htdocs\techno-link\resources\views/website/contact/contact.blade.php ENDPATH**/ ?>