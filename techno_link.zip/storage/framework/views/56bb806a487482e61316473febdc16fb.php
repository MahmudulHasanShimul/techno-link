

<?php $__env->startSection('title'); ?>
Techno Link | Customers List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <!-- Start Page Title Area -->
  <div class="page-title-area">
    <div class="container">
        <div class="page-title-content">

        </div>
    </div>
</div>
<!-- End Page Title Area -->

<!-- Start Customer form Area -->

<div class="row mt-5  col-md-10 mx-auto mb-5">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Client List</h4>
            <hr>

            <?php if(Session::get('noti')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('noti')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>


            <?php if(Session::get('msg')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('msg')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-striped border table-hover">
                    <thead>
                        <tr>
                            <th>SL NO</th>
                            <th>Client Name</th>
                            <th>User Id</th>
                            <th>Phone Number</th>
                            <th>Package</th>
                            <th>Package Rate</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($client->name); ?></td>
                                <td><?php echo e($client->user_id); ?></td>
                                <td><?php echo e($client->phone_number); ?></td>
                                <td><?php echo e($client->package); ?> MB</td>
                                <td><?php echo e($client->package_rate); ?></td>
                                <td><?php echo e($client->status == 'Active' ? 'Active' : 'Inactive'); ?></td>

                                <td>
                                    <a href="<?php echo e(route('client.information',['id'=>$client->id])); ?>" class="btn btn-primary" title="Details">
                                        Details
                                    </a>
                                </td>
                            </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Start Customer form Area -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/client/list.blade.php ENDPATH**/ ?>