<?php $__env->startSection('title'); ?>
Team & Support | Techno Link
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

        <!-- Start Page Title Area -->
        <div class="page-title-area">
            <div class="container">
                <div class="page-title-content">
                    
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start Team Area -->
        <section class="team-area ptb-100">
            <div class="container">
                <div class="single-team-member">
                    <div class="member-image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/team-img1.jpg" alt="image">
                    </div>

                    <div class="member-content">
                        <h3>Agaton Ronald</h3>
                        <span>CEO & Founder</span>

                        <ul class="info">
                            <li><span>Experience:</span> 7 Years</li>
                            <li><span>Phone:</span> <a href="#">+2(976) 432-998</a></li>
                            <li><span>E-mail:</span> <a href="#"><span class="__cf_email__" data-cfemail="d7beb9b1b897aeb8a2a5a4bea3b2b9b6bab2f9b4b8ba">[email&#160;protected]</span></a></li>
                            <li><span>Location:</span> 176, Street Name, New York, NY 10014176, USA</li>
                        </ul>

                        <ul class="social">
                            <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="single-team-member">
                    <div class="member-image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/team-img2.jpg" alt="image">
                    </div>

                    <div class="member-content">
                        <h3>Sarah Taylor</h3>
                        <span>Worker</span>

                        <ul class="info">
                            <li><span>Experience:</span> 7 Years</li>
                            <li><span>Phone:</span> <a href="#">+2(976) 432-998</a></li>
                            <li><span>E-mail:</span> <a href="#"><span class="__cf_email__" data-cfemail="f891969e97b881978d8a8b918c9d9699959dd69b9795">[email&#160;protected]</span></a></li>
                            <li><span>Location:</span> 176, Street Name, New York, NY 10014176, USA</li>
                        </ul>

                        <ul class="social">
                            <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="single-team-member">
                    <div class="member-image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/team-img3.jpg" alt="image">
                    </div>

                    <div class="member-content">
                        <h3>Robert Reed</h3>
                        <span>Worker</span>

                        <ul class="info">
                            <li><span>Experience:</span> 7 Years</li>
                            <li><span>Phone:</span> <a href="#">+2(976) 432-998</a></li>
                            <li><span>E-mail:</span> <a href="#"><span class="__cf_email__" data-cfemail="7811161e173801170d0a0b110c1d1619151d561b1715">[email&#160;protected]</span></a></li>
                            <li><span>Location:</span> 176, Street Name, New York, NY 10014176, USA</li>
                        </ul>

                        <ul class="social">
                            <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="single-team-member">
                    <div class="member-image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/team-img4.jpg" alt="image">
                    </div>

                    <div class="member-content">
                        <h3>Joe Root</h3>
                        <span>Support</span>

                        <ul class="info">
                            <li><span>Experience:</span> 7 Years</li>
                            <li><span>Phone:</span> <a href="#">+2(976) 432-998</a></li>
                            <li><span>E-mail:</span> <a href="#"><span class="__cf_email__" data-cfemail="7a13141c153a03150f0809130e1f141b171f54191517">[email&#160;protected]</span></a></li>
                            <li><span>Location:</span> 176, Street Name, New York, NY 10014176, USA</li>
                        </ul>

                        <ul class="social">
                            <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="single-team-member">
                    <div class="member-image">
                        <img src="<?php echo e(asset('/')); ?>website/assets/img/team-img5.jpg" alt="image">
                    </div>

                    <div class="member-content">
                        <h3>Heather Knight</h3>
                        <span>Support</span>

                        <ul class="info">
                            <li><span>Experience:</span> 7 Years</li>
                            <li><span>Phone:</span> <a href="#">+2(976) 432-998</a></li>
                            <li><span>E-mail:</span> <a href="#"><span class="__cf_email__" data-cfemail="432a2d252c033a2c3631302a37262d222e266d202c2e">[email&#160;protected]</span></a></li>
                            <li><span>Location:</span> 176, Street Name, New York, NY 10014176, USA</li>
                        </ul>

                        <ul class="social">
                            <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Team Area -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\a-xampp\htdocs\techno-link\resources\views/website/support/support.blade.php ENDPATH**/ ?>