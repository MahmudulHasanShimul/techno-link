<?php $__env->startSection('title'); ?>
Contact | Techno Link
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

        <!-- Start Page Title Area -->
        <div class="page-title-area">
            <div class="container">
                <div class="page-title-content">

                </div>
            </div>
        </div>
        <!-- End Page Title Area -->


        <!-- Start Contact Info Box Area -->
        <section class="contact-info-box-area ptb-100 pb-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-contact-info">
                            <div class="icon">
                                <i class="flaticon-place"></i>
                            </div>
                            <h3>Address</h3>
                            <p style="font-weight: bold">34/58, Agradut School Road, Sontek, Dhania, Jatrabari, Dhaka-1236</p>

                            <div class="image-box">
                                <img src="assets/img/shape-image/1.png" alt="image">
                                <img src="assets/img/shape-image/1.png" alt="image">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-contact-info">
                            <div class="icon">
                                <i class="flaticon-address-book"></i>
                            </div>
                            <h3>Email</h3>
                            <p><a href="#"><span class="__cf_email__" data-cfemail="e58c8b838aa59c8a9097968c91808b848880cb868a88">technolink021@gmail.com</span></a></p>
                            <p><a href="#"><span class="__cf_email__" data-cfemail="b8cfcfcf96c1d7cdcad6d9d5ddf8dfd5d9d1d496dbd7d5">technoenterprise90@gmail.com</span></a></p>

                            <div class="image-box">
                                <img src="assets/img/shape-image/1.png" alt="image">
                                <img src="assets/img/shape-image/1.png" alt="image">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3">
                        <div class="single-contact-info">
                            <div class="icon">
                                <i class="flaticon-signal"></i>
                            </div>
                            <h3>Phone</h3>
                            <p><a href="#">+880 1842-955049</a></p>
                            <p><a href="#">+880 1842-955050</a></p>

                            <div class="image-box">
                                <img src="assets/img/shape-image/1.png" alt="image">
                                <img src="assets/img/shape-image/1.png" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Info Box Area -->

        <!-- Start Contact Area -->
        <section class="contact-area ptb-100">
            <div class="container">
                <div class="section-title">
                    <span>Subscribe</span>
                    <h2>Drop your information here</h2>
                </div>

                <?php if(Session::get('msg')): ?>
                    <div class="col-md-10 mx-auto alert alert-warning alert-dismissible fade show" role="alert">
                        <strong><?php echo e(Session::get('msg')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form class="col-md-10 mx-auto" action="<?php echo e(route('client.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Your Name<span
                                    class="text-danger">*</span> </label>
                                <input type="text" class="form-control" placeholder="Your Name" name="name" value="<?php echo e(old('name')); ?>" id="name" required data-error="Please enter your name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Your User ID<span
                                    class="text-danger">*</span> </label>
                                <input type="text" class="form-control" placeholder="Your User ID" name="user_id" value="<?php echo e(old('user_id')); ?>" id="email" required data-error="Please enter your User ID">
                                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Your Phone Number<span
                                    class="text-danger">*</span> </label>                                 
                                    <input type="text" class="form-control" name="phone_number" value="<?php echo e(old('phone_number')); ?>" placeholder="Phone Number" id="phone_number" required data-error="Please enter your number">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Connection Date</label>
                                <input type="date" class="form-control" name="connection_month" value="<?php echo e(old('connection_month')); ?>" placeholder="Connection Date" id="customDate" onchange="customDate()" data-error="Connection Date">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Submit NID Front Side</label>
                                <input type="file" class="form-control" name="nid_front_side" accept="image/*" placeholder="Submit NID Front Side" id="msg_subject" data-error="Please enter your subject">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Submit NID Back Side</label>
                                <input type="file" class="form-control" name="nid_back_side" accept="image/*" placeholder="Submit NID Back Side" id="msg_subject"  data-error="Please enter your subject">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-12 col-md-12">
                            <div class="form-group">
                                <label for="exampleInputuname3" class="col-md-6 control-label">Your Address</label>
                                <textarea style="height: 80px" name="address" class="form-control" id="message" placeholder="Your Address" data-error="Your Address"><?php echo e(old('address')); ?></textarea>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-lg-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Send Message</button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
        <!-- Start Contact Area -->

        <!-- Start Map Area -->
        <div id="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d913.2953021491431!2d90.44634146962694!3d23.705222126619336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b98b57057851%3A0x774b297ccadc0d95!2sTechno%20Link!5e0!3m2!1sen!2sbd!4v1684929972286!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <!-- End Map Area -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/website/contact/contact.blade.php ENDPATH**/ ?>