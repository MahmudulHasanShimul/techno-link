 <!-- Bootstrap Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/bootstrap.min.css">
 <!-- Animate Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/animate.min.css">
 <!-- FontAwesome Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/fontawesome.min.css">
 <!-- Magnific Popup Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/magnific-popup.min.css">
 <!-- Flaticon CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/flaticon.css">
 <!-- Nice Select Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/nice-select.min.css">
 <!-- MeanMenu CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/meanmenu.css">
 <!-- Owl Carousel Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/owl.carousel.min.css">
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/owl.theme.default.min.css">
 <!-- Style CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/style.css">
 <!-- Responsive CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/responsive.css">
 <!-- Dark Style CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/dark-style.css">
<?php /**PATH F:\Shimul\Web Development\a-xampp\htdocs\techno-link\resources\views/website/includes/style.blade.php ENDPATH**/ ?>