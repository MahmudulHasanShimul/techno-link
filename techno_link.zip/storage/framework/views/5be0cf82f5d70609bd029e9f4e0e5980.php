 <!-- jQuery Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/jquery.min.js"></script>
 <!-- Bootstrap Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/bootstrap.bundle.min.js"></script>
 <!-- MeanMenu JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/jquery.meanmenu.js"></script>
 <!-- Magnific Popup Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/jquery.magnific-popup.min.js"></script>
 <!-- Owl Carousel Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/owl.carousel.min.js"></script>
 <!-- Parallax Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/parallax.min.js"></script>
 <!-- Nice Select Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/jquery.nice-select.min.js"></script>
 <!-- WOW Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/wow.min.js"></script>
 <!-- AjaxChimp Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/jquery.ajaxchimp.min.js"></script>
 <!-- Form Validator Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/form-validator.min.js"></script>
 <!-- Contact Form Min JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/contact-form-script.js"></script>
 <!-- Main JS -->
 <script src="<?php echo e(asset('/')); ?>website/assets/js/main.js"></script>
<?php /**PATH F:\Shimul\Web Development\a-xampp\htdocs\techno-link\resources\views/website/includes/script.blade.php ENDPATH**/ ?>