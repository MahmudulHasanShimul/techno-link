 <!-- Bootstrap Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/bootstrap.min.css">
 <!-- Animate Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/animate.min.css">
 <!-- FontAwesome Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/fontawesome.min.css">
 <!-- Magnific Popup Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/magnific-popup.min.css">
 <!-- Flaticon CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/flaticon.css">
 <!-- Nice Select Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/nice-select.min.css">
 <!-- MeanMenu CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/meanmenu.css">
 <!-- Owl Carousel Min CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/owl.carousel.min.css">
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/owl.theme.default.min.css">

 <link href="<?php echo e(asset('/')); ?>website/assets/node_modules/toast-master/css/jquery.toast.css" rel="stylesheet">
 <link href="<?php echo e(asset('/')); ?>website/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('/')); ?>website/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css" rel="stylesheet" type="text/css">
 <!-- Style CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/style.css">
 <!-- Responsive CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/responsive.css">
 <!-- Dark Style CSS -->
 <link rel="stylesheet" href="<?php echo e(asset('/')); ?>website/assets/css/dark-style.css">
<?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/website/includes/style.blade.php ENDPATH**/ ?>