

<?php $__env->startSection('title'); ?>
Techo Link - Re-Seller Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Start Page Title Area -->
<div class="page-title-area">
    <div class="container">
        <div class="page-title-content">

        </div>
    </div>
</div>
<!-- End Page Title Area -->
    
<section class="m-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="list-group">
                    <a href="<?php echo e(route('reseller.dashboard',['id' => Session::get('reSeller_id')])); ?>" class="list-group-item list-group-item-action">Dashboard</a>
                    <a href="<?php echo e(route('client.create')); ?>" class="list-group-item list-group-item-action">Customer Subscription Form</a>
                    <a href="<?php echo e(route('client.list')); ?>" class="list-group-item list-group-item-action">Customers List</a>
                    <a href="<?php echo e(route('reseller.logout')); ?>" class="list-group-item list-group-item-action">Logout</a>
                </div>
            </div>

            <div class="col-md-8 mx-auto mt-4">
                <div class="card">
                    <center>
                        <img src="<?php echo e(asset($reSeller->image)); ?>" class="mt-4" alt="Re-seller Image" height="300px" width="250px">
                    </center>
                    <div class="card-body text-center">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <td><h2 class="card-title fw-bolder" style="color: #C97817"><?php echo e($reSeller->owner_name); ?></h2></td>
                            </tr>
                            <tr>
                                <td><h4 class="card-title"><?php echo e($reSeller->company_name); ?></h4></td>
                            </tr>
                            <tr>
                                <td><p class="card-text">Mobile: <?php echo e($reSeller->mobile); ?></p></td>
                            </tr>
                            <tr>
                                <td><p class="card-text">Email: <?php echo e($reSeller->email); ?></p></td>
                            </tr>
                            <tr>
                                <td><p class="card-text">Address: <?php echo e($reSeller->address); ?></p></td>
                            </tr>
                            <tr>
                                <td>
                                    <?php if($reSeller->status == 1): ?>
                                        <p class="card-text">Active Status : <span style="color: green; font-weight:bold">Active</span></p>
                                    <?php else: ?>
                                        <p class="card-text">Active Status : <span style="color: red; font-weight:bold">Inactive</span></p> 
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/reSeller/dashboard.blade.php ENDPATH**/ ?>