<!doctype html>
<html lang="zxx">

<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

       <?php echo $__env->make('website.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <link rel="icon" type="image/png" href="<?php echo e(asset('/')); ?>website/assets/img/TL-dark.png">
    </head>

    <body>

        <!-- Start Preloader Area -->
        <div class="preloader">
            <div class="spinner"></div>
        </div>
        <!-- End Preloader Area -->

         <!-- Start Header Area -->
       <?php echo $__env->make('website.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Header Area -->

       <?php echo $__env->yieldContent('content'); ?>

        <!-- Start Footer Area -->
       <?php echo $__env->make('website.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Footer Area -->

        <div class="go-top"><i class="fas fa-arrow-up"></i></div>

       <?php echo $__env->make('website.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>

</html>
<?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/website/master.blade.php ENDPATH**/ ?>