


<?php $__env->startSection('body'); ?>
<!-- Start Customer details Area -->

<div class="row mt-5  col-md-10 mx-auto mb-5">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Client Deatils</h4>
            <hr>

            <?php if(Session::get('noti')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('noti')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>


            <?php if(Session::get('msg')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('msg')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-striped border">
                    <tr>
                        <th>Re-seller Name</th>
                        <td><?php echo e($client->reSeller_owner_name); ?></td>
                    </tr>
                    <tr>
                        <th>Client Name</th>
                        <td><?php echo e($client->name); ?></td>
                    </tr>
                    <tr>
                        <th>User Id</th>
                        <td><?php echo e($client->user_id); ?></td>
                    </tr>
                    <tr>
                        <th>Phone Number</th>
                        <td><?php echo e($client->phone_number); ?></td>
                    </tr>
                    <tr>
                        <th>Date of Connection</th>
                        <td><?php echo e($client->connection_month); ?></td>
                    </tr>
                    <tr>
                        <th>Package</th>
                        <td><?php echo e($client->package); ?> MB</td>
                    </tr>
                    <tr>
                        <th>Package Rate</th>
                        <td><?php echo e($client->package_rate); ?></td>
                    </tr>
                    
                    <tr>
                        <th>Address</th>
                        <td><?php echo e($client->address); ?></td>
                    </tr>

                    <tr>
                        <th>NID Front Side</th>
                        <td>
                            <img src="<?php echo e(asset($client->nid_front_side)); ?>" alt="Not Uploaded" height="50px" width="80px">
                        </td>
                    </tr>
                    <tr>
                        <th>NID Back Side</th>
                        <td>
                            <img src="<?php echo e(asset($client->nid_back_side)); ?>" alt="Not Uploaded" height="50px" width="80px">
                        </td>
                    </tr>

                    <tr>
                        <th>Status</th>
                        <td>
                            <?php if($client->status == 'Active'): ?>
                                <p class="card-text" style="color: green; font-weight:bold">Active</span></p>
                            <?php else: ?>
                                <p class="card-text" style="color: red; font-weight:bold">Inactive</p> 
                            <?php endif; ?>
                        </td>
                    </tr>
                   
                    <tr>
                        <th>Action</th>
                        <td style ="width:"80px">
                            <a href="<?php echo e(route('resellerWiseClient.list',['id'=>$client->reSeller_id])); ?>" class="btn btn-primary m-1" title="Back">Back</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Start Customer details Area -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/admin/reSeller/client-details.blade.php ENDPATH**/ ?>