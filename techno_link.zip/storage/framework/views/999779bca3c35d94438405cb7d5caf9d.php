
<?php /**PATH F:\Shimul\Web Development\aa-xampp\htdocs\techno-link\resources\views/auth/register.blade.php ENDPATH**/ ?>