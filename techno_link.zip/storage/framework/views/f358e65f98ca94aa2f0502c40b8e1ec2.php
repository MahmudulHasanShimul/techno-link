


<?php $__env->startSection('body'); ?>
<div class="row mt-3">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Reseller Details</h4>
            <hr>

            <?php if(Session::get('noti')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('noti')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>


            <?php if(Session::get('msg')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('msg')); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-striped border table-hover">
                    <tr>
                        <th>Re-seller Id</th>
                        <td><?php echo e($reSeller->id); ?></td>
                    </tr>
                    <tr>
                        <th>Company Name</th>
                        <td><?php echo e($reSeller->company_name); ?></td>
                    </tr>
                    <tr>
                        <th>Owner Name</th>
                        <td><?php echo e($reSeller->owner_name); ?></td>
                    </tr>
                    <tr>
                        <th>Mobile Number</th>
                        <td><?php echo e($reSeller->mobile); ?></td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($reSeller->email); ?></td>
                    </tr>
                    <tr>
                        <th>Address</th>
                        <td><?php echo e($reSeller->address); ?></td>
                    </tr>
                    <tr>
                        <th>Owner Image</th>
                        <td>
                            <img src="<?php echo e(asset($reSeller->image)); ?>" alt="" height="80px" width="110px">
                        </td>
                    </tr>
                    <tr>
                        <th>Line Activation Date</th>
                        <td><?php echo e($reSeller->activation_date); ?></td>
                    </tr>
                    <tr>
                        <th>Active Status</th>
                        <td>
                            <?php if($reSeller->status == 1): ?>
                                <p class="card-text" style="color: green; font-weight:bold">Active</span></p>
                            <?php else: ?>
                                <p class="card-text" style="color: red; font-weight:bold">Inactive</p> 
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Action</th>
                        <td style ="width:"80px">
                            <a href="<?php echo e(route('reselller.edit',['id'=>$reSeller->id])); ?>" class="btn btn-success" title="Edit">Edit</a>
                            <a href="<?php echo e(route('reselller.manage')); ?>" class="btn btn-primary" title="Edit">Back</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Shimul\Web Development\aaa-xampp\htdocs\techno-link\resources\views/admin/reSeller/details.blade.php ENDPATH**/ ?>